# CS3200 – Assignment 5: MongoDB Tweet Queries

Querying the ieeevis2020 tweet dataset using Node.js and MongoDB.

---

## Setup

### 1. Download the dataset

Download this file:
```
https://johnguerra.co/viz/influentials/ieeevis/ieeevis2020/ieeevis2020Tweets.dump.bz2
```

### 2. Unzip it

- **Windows:** right-click the file → 7-Zip → Extract here
- **Mac:** double-click the file (use Keka if it doesn't open automatically)

You should end up with a file called `ieeevis2020Tweets.dump`.

### 3. Import into MongoDB

Make sure MongoDB is running, then run this in your terminal:

```bash
mongoimport -h localhost:27017 -d ieeevisTweets -c tweet --file ieeevis2020Tweets.dump
```

### 4. Install dependencies

```bash
npm install
```

---

## Running the queries

```bash
node Query1.js
node Query2.js
node Query3.js
node Query4.js
node Query5.js
```

---

## What each query does

**Query1.js** — Counts tweets that are not retweets and not replies.

**Query2.js** — Returns the top 10 users by number of followers.

**Query3.js** — Finds the user who posted the most tweets in the dataset.

**Query4.js** — Finds the top 10 users with the highest average retweets, only counting users who tweeted more than 3 times.

**Query5.js** — Splits the data into two cleaner collections:
- `users` — one document per unique user
- `tweets_only` — all tweets, with the user object replaced by a `user_id` reference

---

## Project structure

```
ieeevis-tweets/
├── Query1.js
├── Query2.js
├── Query3.js
├── Query4.js
├── Query5.js
├── package.json
└── README.md
```

> Note: the `node_modules/` folder is excluded from this repo via `.gitignore`.

